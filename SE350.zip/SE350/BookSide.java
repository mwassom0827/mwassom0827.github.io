package SE350;

public enum BookSide{
    BUY,SELL
}
