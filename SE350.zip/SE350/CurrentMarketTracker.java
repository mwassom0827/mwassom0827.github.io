package SE350;

public class CurrentMarketTracker {

    private static CurrentMarketTracker instance;
    private CurrentMarketTracker(){

    }
    public static synchronized CurrentMarketTracker getInstance(){
        if(instance==null){
            instance = new CurrentMarketTracker();
        }
            return instance;

    }

    public void updateMarket(String symbol, Price buyPrice, int buyVolume, Price sellPrice, int sellVolume) throws InvalidPriceOperation {
        Price marketWidth;
        if(buyPrice==null){
            buyPrice=new Price(0);
        }
        if(sellPrice==null){
            sellPrice=new Price(0);
        }

        marketWidth = sellPrice.subtract(buyPrice);
        if(marketWidth.isNegative()){
            marketWidth=new Price(0);
        }


        CurrentMarketSide buySide = new CurrentMarketSide(buyPrice,buyVolume);
        CurrentMarketSide sellSide = new CurrentMarketSide(sellPrice,sellVolume);

        System.out.println("*********** Current Market ***********");
        System.out.printf("* %s %sx%d - %sx%d [%s]\n",symbol, buyPrice,buyVolume,sellPrice,sellVolume, marketWidth);
        //System.out.println(buyPrice);
        //System.out.println(symbol);
        System.out.println("**************************************");

        CurrentMarketPublisher.getInstance().acceptCurrentMarket(symbol,buySide,sellSide);
    }
}
