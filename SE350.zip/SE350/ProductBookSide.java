package SE350;

import java.util.*;

public class ProductBookSide {
    private final BookSide side;
    private final HashMap<Price,ArrayList<Order>> bookEntries;

    public ProductBookSide(BookSide side) throws InvalidInputException{
        this.side =side;
        this.bookEntries =new HashMap<>();
    }
    public OrderDTO add(Order o) throws InvalidInputException{
        Price price=o.getPrice();

        if(!bookEntries.containsKey(price)){
            bookEntries.put(price,new ArrayList<>());
        }
        ArrayList<Order> orders=bookEntries.get(price);
        OrderDTO orderDTO=o.makeTradableDTO();
        orders.add(o);
        return orderDTO;
    }

    public OrderDTO cancel(String orderId) throws InvalidInputException {
        List<Price> pricesToRemove= new ArrayList<>();
        OrderDTO orderDTO=null;

        for(Map.Entry<Price,ArrayList<Order>> entry : bookEntries.entrySet()){
            ArrayList<Order> orders=entry.getValue();

            Iterator<Order> orderIterator =orders.iterator();
            while (orderIterator.hasNext()){
                Order order=orderIterator.next();
                if (order.getId().equals(orderId)){
                    orderIterator.remove();

                    if (orders.isEmpty()){
                        pricesToRemove.add(entry.getKey());
                    }
                    orderDTO = new OrderDTO(
                            order.getUser(),
                            order.getProduct(),
                            order.getSide().toString(),
                            order.getId(),
                            order.getOriginalVolume(),
                            order.getRemainingVolume(),
                            order.getCancelledVolume(),
                            order.getFilledVolume(),
                            entry.getKey().toString()
                    );
                    order.setCancelledVolume(order.getRemainingVolume());


                    break;
                }
            }
        }

        for(Price price:pricesToRemove){
            bookEntries.remove(price);
        }


        return orderDTO;
    }

    public Price topOfBookPrice(){
        Price topPrice=null;

        for(Price price: bookEntries.keySet()){
            if(topPrice==null){
                topPrice=price;
            }else if(side==BookSide.BUY&&price.compareTo(topPrice)>0){
                topPrice=price;
            }else if(side==BookSide.SELL&&price.compareTo(topPrice)<0){
                topPrice=price;
            }
        }
        return topPrice;
    }
    public int topOfBookVolume(){
        Price topPrice = topOfBookPrice();

        if(topPrice!=null){
            ArrayList<Order> orders =bookEntries.get(topPrice);
            int totalVolume=0;

            for(Order order:orders){
                totalVolume+=order.getRemainingVolume();
            }
            return totalVolume;
        }
        return 0;
    }

    public void tradeOut(Price price,int vol) throws InvalidInputException {
        ArrayList<Order> orders=bookEntries.get(price);
        if(orders==null){
            return;
        }

        Iterator<Order> iterator= orders.iterator();
        while(iterator.hasNext()&&vol>0){
            Order order= iterator.next();
            int orderRemainingVol= order.getRemainingVolume();

            if(orderRemainingVol<=vol){
                //System.out.println(vol);
                order.setFilledVolume(order.getFilledVolume()+vol);
                //System.out.println(vol);
                order.setRemainingVolume(0);
                String fillMessage="   FILL: ("+order.getSide()+" "+vol+") "+order.toString();
                System.out.println(fillMessage);
                vol -=orderRemainingVol;



            } else{
                order.setRemainingVolume(orderRemainingVol-vol);
                order.setFilledVolume(order.getFilledVolume()+vol);
                String partialFillMessage = "   PARTIAL FILL: ("+order.getSide()+" "+vol+") "+order.toString();
                System.out.println(partialFillMessage);
                vol=0;
            }

            if(order.getRemainingVolume()==0){

                iterator.remove();
            }
        }
        if (orders.isEmpty()){
            bookEntries.remove(price);
        }
    }

    @Override
    public String toString(){
        StringBuilder sb= new StringBuilder();
        sb.append("\n").append("Side:").append(side).append("\n");

        List<Price> sortedPrices = new ArrayList<>(bookEntries.keySet());
        sortedPrices.sort(Comparator.reverseOrder());
        if(sortedPrices.isEmpty()){
            sb.append("  <Empty>\n");
        }else{
            for (Price price:sortedPrices){

                sb.append("  Price: ").append(price).append("\n");

                for(Order order:bookEntries.get(price)){

                    String orderString= order.toString().replace("\n", "\n    ");
                    sb.append("    ").append(orderString).append("\n");

                }
            }
        }


        return sb.toString();

    }
}
