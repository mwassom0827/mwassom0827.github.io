package SE350;

public class Order {

    private final String user ;
    private final String product;
    private final Price price;
    private final BookSide side;
    private final String id;
    private final int originalVolume ;
    private int remainingVolume;
    private int cancelledVolume;
    private int filledVolume;

    public Order(String user,String product,Price price,int originalVolume,BookSide side) throws InvalidInputException{


        if (!isValidUser(user)||!isValidProduct(product)||originalVolume<=0||originalVolume>= 10000){
            throw new InvalidInputException("Invalid Input Parameters");
        }



        this.user= user;
        this.product= product;
        this.price= price;
        this.side= side;
        this.originalVolume= originalVolume;
        this.remainingVolume= originalVolume;
        this.cancelledVolume= 0;
        this.filledVolume=0;

        long nanoTime=System.nanoTime();
        String priceString=price.toString();
        this.id= user+product+priceString+nanoTime;


    }

    public boolean isValidUser(String user){
        return user!=null&& user.matches("[A-Z]{3}$");
    }

    private boolean isValidProduct(String product){
        return product!=null&& product.matches("^[A-Za-z0-9.]{1,5}$");
    }

    public String getUser(){

        return user;
    }
    public String getProduct(){
        return product;

    }
    public Price getPrice(){

        return price;
    }
    public BookSide getSide(){

        return side;
    }
    public String getId(){

        return id;
    }
    public int getOriginalVolume(){

        return originalVolume;
    }

    public int getRemainingVolume(){
        return remainingVolume;

    }
    public int getCancelledVolume(){

        return cancelledVolume;
    }
    public int getFilledVolume(){

        return filledVolume;
    }

    public void setCancelledVolume(int cancelledVolume) throws InvalidInputException{
        if(cancelledVolume<0||cancelledVolume>originalVolume){
            throw new InvalidInputException("Invalid cancelled volume");
        }
        this.cancelledVolume= cancelledVolume;
    }
    public void setRemainingVolume(int remainingVolume) throws InvalidInputException{
        if(remainingVolume<0||remainingVolume>originalVolume){
            throw new InvalidInputException("Invalid remaining volume");
        }
        this.remainingVolume=remainingVolume;
    }

    public void setFilledVolume(int filledVolume) throws InvalidInputException{
        if (filledVolume<0){
            throw new InvalidInputException("Invalid filled volume");
        }

        this.filledVolume=filledVolume;
    }

    @Override
    public String toString(){
        return String.format("%s order: %s %s at %s, Orig Vol: %d, Rem Vol: %d, Fill Vol: %d, CXL Vol: %d, ID: %s",user,side,product,price,originalVolume,remainingVolume,filledVolume,cancelledVolume,id);
    }

    public OrderDTO makeTradableDTO(){
        return new OrderDTO(
                user,
                product,
                side.toString(),
                id,
                originalVolume,
                remainingVolume,
                cancelledVolume,
                filledVolume,
                price.toString());

    }

}