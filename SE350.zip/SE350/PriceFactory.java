package SE350;
import java.util.HashMap;
public abstract class PriceFactory {

    private static HashMap<Integer,Price> prices=new HashMap<>();

    public static Price makePrice(int value){

        if(prices.containsKey(value)){
            return prices.get(value);
        }else{
            Price price = new Price(value);
            prices.put(value,price);
            return price;
        }
    }
    public static Price makePrice(String stringValueIn){

        int cents= parseCentsFromStringValue(stringValueIn);

        if(prices.containsKey(cents)){
            return prices.get(cents);
        }else{
            Price price = new Price(cents);
            prices.put(cents,price);
            return price;
        }
    }
    private static int parseCentsFromStringValue(String stringValueIn) {
        // removing unnecessary characters and parsing the string to get cents
        stringValueIn=stringValueIn.replaceAll(",","");
        stringValueIn=stringValueIn.replace("$","");
        stringValueIn=stringValueIn.replace(".","");

        boolean negative= false;
        if (stringValueIn.charAt(0)=='-'){
            negative=true;
            stringValueIn=stringValueIn.substring(1);
        }
        int cents=Integer.parseInt(stringValueIn);

        if (negative){
            cents= -cents;
        }

        return cents;
    }
}
