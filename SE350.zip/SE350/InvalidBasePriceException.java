package SE350;

public class InvalidBasePriceException extends Exception {

    public InvalidBasePriceException(String msg){
        super(msg);
    }
}
