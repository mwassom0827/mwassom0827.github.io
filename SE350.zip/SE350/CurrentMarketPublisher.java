package SE350;

import java.util.ArrayList;
import java.util.HashMap;

public class CurrentMarketPublisher {

    private static CurrentMarketPublisher instance;
    private final HashMap<String,ArrayList<CurrentMarketObserver>>filters;

    private CurrentMarketPublisher(){
        filters = new HashMap<>();
    }
    public static CurrentMarketPublisher getInstance(){
        if(instance==null){
            instance=new CurrentMarketPublisher();

        }
        return instance;
    }

    public void subscribeCurrentMarket(String symbol,CurrentMarketObserver cmo){
        if(!filters.containsKey(symbol)){
            filters.put(symbol, new ArrayList<>());

        }
        filters.get(symbol).add(cmo);
    }

    public void unsubscribeCurrentMarket(String symbol,CurrentMarketObserver cmo){
        if(filters.containsKey(symbol)){
            filters.get(symbol).remove(cmo);}


    }

    public void acceptCurrentMarket(String symbol,CurrentMarketSide buySide,CurrentMarketSide sellSide){
        if (!filters.containsKey(symbol)){
            return;
        }
        ArrayList<CurrentMarketObserver> observers=filters.get(symbol);
        for(CurrentMarketObserver observer:observers){
            observer.updateCurrentMarket(symbol,buySide,sellSide);
        }
    }

}
