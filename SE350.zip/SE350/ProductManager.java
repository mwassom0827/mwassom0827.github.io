package SE350;

import java.util.HashMap;
import java.util.Random;

public class ProductManager {

    private static ProductManager instance;
    private final HashMap<String,ProductBook> productBooks;

    private ProductManager(){
        productBooks = new HashMap<>();

    }
    public static ProductManager getInstance(){
        if(instance==null){
            instance=new ProductManager();
        }
        return instance;
    }

    public void addProduct(String symbol) throws InvalidInputException {
        if(!productBooks.containsKey(symbol)){
            ProductBook productBook = new ProductBook(symbol);
            productBooks.put(symbol,productBook);
        }
    }

    public String getRandomProduct(){
        if (productBooks.isEmpty()) {
            return null;
        }

        Random random = new Random();
        Object[] keys = productBooks.keySet().toArray();
        return (String) keys[random.nextInt(keys.length)];
    }

    public OrderDTO addOrder(Order o) throws InvalidInputException, InvalidPriceOperation {
        String productSymbol = o.getProduct();
        ProductBook productBook = productBooks.get(productSymbol);
        if(productBook!=null){
            return productBook.add(o);
        }
        return null;
    }

    public OrderDTO cancel (OrderDTO o) throws InvalidInputException, InvalidPriceOperation {
        String productSymbol = o.product;
        ProductBook productBook = productBooks.get(productSymbol);
        if(productBook!=null){
            return productBook.cancel(BookSide.valueOf(o.side),o.id);
        }
        else{
            return null;
        }
    }

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("ProductBook:\n");
        for(ProductBook productBook: productBooks.values()){
            sb.append(productBook.toString());
        }
        return sb.toString();
    }

}
