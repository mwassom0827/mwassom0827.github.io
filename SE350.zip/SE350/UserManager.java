package SE350;

import java.util.HashMap;
import java.util.Random;

public class UserManager {
    private static UserManager instance = null;
    private static HashMap<String,User> users;

    private UserManager(){
        users=new HashMap<>();
    }

    public static UserManager getInstance(){
        if(instance==null){
            instance =new UserManager();

        }
        return instance;
    }

    public void init(String[] usersIn) throws InvalidUserException {
        for (String userId:usersIn){
            User newUser =new User(userId);
            users.put(userId,newUser);

        }
    }

    public User getRandomUser(){
        if(users.isEmpty()){
            return null;
        }
        Random randomUser= new Random();
        int index=randomUser.nextInt(users.size());
        return users.values().toArray(new User[0])[index];
    }

    public void addToUser(String userId,OrderDTO o){
        if(users.containsKey(userId)){
            User user =users.get(userId);
            user.addOrder(o);
        }
    }

    public static User getUser(String id){
        return users.get(id);
    }

    @Override
    public String toString() {
        StringBuilder sb= new StringBuilder();
        sb.append("Users:\n\n");
        for (User user : users.values()){
            sb.append(" "+ user.toString()).append("\n");
        }
        return sb.toString();

    }
}


