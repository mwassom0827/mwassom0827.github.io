package SE350;

import java.util.Objects;

public class Price implements Comparable<Price> {

    private int cents;


    public Price(int centsIn){
        cents = centsIn;

    }

    public boolean isNegative(){
        return cents<0;


    }

    public Price add(Price p) throws InvalidPriceOperation{
        if (p==null){
            throw new InvalidPriceOperation("Addition with null isn't allowed");
        }

        int newCents= this.cents+p.cents;
        return PriceFactory.makePrice(newCents);

    }
    public Price subtract(Price p) throws InvalidPriceOperation {
        if (p==null){
            throw new InvalidPriceOperation("Subtraction with null isn't allowed");
        }
        int newCents= this.cents-p.cents;
        return PriceFactory.makePrice(newCents);
    }

    public Price multiply(int n) throws InvalidPriceOperation{
        if (n<0){
            throw new InvalidPriceOperation("Multiplication with 0 or negative isn't allowed");
        }

        int newCents= this.cents*n;
        return PriceFactory.makePrice(newCents);
    }
    public boolean greaterOrEqual(Price p) throws InvalidPriceOperation{
        if (p==null){
            throw new InvalidPriceOperation("greaterOrEqual with null isn't allowed");
        }

        return this.cents>=p.cents;


    }
    public boolean lessOrEqual(Price p) throws InvalidPriceOperation{
        if (p==null){
            throw new InvalidPriceOperation("lessOrEqual with null isn't allowed");
        }

        return this.cents<=p.cents;
    }
    public boolean lessThan(Price p) throws InvalidPriceOperation{
        if (p==null){
            throw new InvalidPriceOperation("lessThan with null isn't allowed");
        }
        return this.cents>p.cents;

    }
    public boolean greaterThan(Price p) throws InvalidPriceOperation{
        if (p==null){
            throw new InvalidPriceOperation("greaterThan with null isn't allowed");
        }
        return this.cents<p.cents;

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if(o==null||getClass()!=o.getClass()) return false;
        Price price = (Price) o;
        return cents == price.cents;
    }

    @Override
    public int hashCode() {
        return Objects.hash(cents);
    }
    @Override
    public int compareTo(Price p) {
       if(p==null) return -1;
       return (int) (cents - p.cents);
    }

    @Override
    public String toString(){
        //get absolute value of number of dollars
        int dollars = Math.abs(this.cents /100);
        //get absolute value of leftover cents
        int leftoverCents = Math.abs(this.cents %100);

        String sign;
        //if cents is negative then the sign is set to char '-', otherwise itll just be nothing
        if(this.cents<0){
            sign="-";

        }else{
            sign="";
        }
        //formatting string to fit scheme. %02 places the value into two decimal places, or example if it was just 5 it would print 05
        return String.format("%s$%d.%02d",sign,dollars,leftoverCents);
    }

}
