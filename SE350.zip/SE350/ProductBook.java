package SE350;

public class ProductBook {
    private final String product;
    private final ProductBookSide buySide;
    private final ProductBookSide sellSide;

    public ProductBook(String product) throws InvalidInputException{
        if(!isValidProduct(product)){
            throw new InvalidInputException("Invalid product");
        }
        this.product=product;
        buySide=new ProductBookSide(BookSide.BUY);
        sellSide=new ProductBookSide(BookSide.SELL);
    }
    private boolean isValidProduct(String product) throws InvalidInputException {
        return product != null && product.matches("^[A-Za-z0-9.]{1,5}$");
    }

    public OrderDTO add(Order o) throws InvalidInputException, InvalidPriceOperation {
        OrderDTO orderDTO=null;

        if(o.getSide()==BookSide.BUY){
            orderDTO=buySide.add(o);
        }else if(o.getSide()==BookSide.SELL){
            orderDTO=sellSide.add(o);
        }
        tryTrade();
        updateMarket();

        return orderDTO;
    }

    public OrderDTO cancel(BookSide side, String orderId) throws InvalidInputException, InvalidPriceOperation {
        if(side==BookSide.BUY){
            return buySide.cancel(orderId);

        }else if(side==BookSide.SELL){
            return sellSide.cancel(orderId);
        }
        updateMarket();



        return null;
    }
    public void tryTrade() throws InvalidPriceOperation, InvalidInputException {
        Price buyPrice=buySide.topOfBookPrice();
        Price sellPrice=sellSide.topOfBookPrice();

        while (buyPrice!=null&&sellPrice!=null&&buyPrice.greaterOrEqual(sellPrice)){
            int buyVolume=buySide.topOfBookVolume();
            int sellVolume=sellSide.topOfBookVolume();
            int tradeVolume= Math.min(buyVolume,sellVolume);
            sellSide.tradeOut(sellPrice,tradeVolume);
            buySide.tradeOut(buyPrice,tradeVolume);
            buyPrice=buySide.topOfBookPrice();
            sellPrice= sellSide.topOfBookPrice();
            }
        }

    private void updateMarket() throws InvalidPriceOperation{
        Price buyPrice=buySide.topOfBookPrice();
        if(buyPrice==null){
            buyPrice=new Price(0);
        }
        int buyVolume=buySide.topOfBookVolume();
        Price sellPrice=sellSide.topOfBookPrice();
        if(sellPrice==null){
            sellPrice=new Price(0);
        }
        int sellVolume=sellSide.topOfBookVolume();

        CurrentMarketTracker.getInstance().updateMarket(product,buyPrice,buyVolume,sellPrice,sellVolume);
    }

    @Override
    public String toString(){

        StringBuilder sb = new StringBuilder();

        sb.append("\nProduct: ").append(product).append(buySide.toString());
        sb.append(sellSide.toString()).append("\n");
        return sb.toString();
        }


}
