package SE350;

public class InvalidPriceOperation extends Exception{
    public InvalidPriceOperation(String msg){
        super(msg);
    }
}
