package SE350;

public class OrderDTO {
    public String user;
    public String product;
    public String side;
    public String id;
    public int originalVolume;
    public int remainingVolume;
    public int cancelledVolume;
    public int filledVolume;
    public String price;

    public OrderDTO(String user,String product,String side,String id,int originalVolume,int remainingVolume,int cancelledVolume,int filledVolume,String price) {
        this.user=user;
        this.product=product;
        this.side=side;
        this.id=id;
        this.originalVolume=originalVolume;
        this.remainingVolume=remainingVolume;
        this.cancelledVolume=cancelledVolume;
        this.filledVolume=filledVolume;
        this.price=price;
    }

    @Override
    public String toString() {
        return String.format("ADD: %s: %s order: %s %s at %s, Orig Vol: %d, Rem Vol: %d, Fill Vol: %d, CXL Vol: %d, ID: %s",side,user,side,product,price,originalVolume,remainingVolume,filledVolume,cancelledVolume,id);}
}
