package SE350;
import java.util.HashMap;

public class User implements CurrentMarketObserver {

    private String userId;
    private final HashMap<String, OrderDTO> orders;
    private final HashMap<String, CurrentMarketSide[]> currentMarkets;

    public User(String userId) throws InvalidUserException {
        setUserId(userId);
        this.orders= new HashMap<>();
        this.currentMarkets=new HashMap<>();
    }

    public String getUserId() {
        return userId;
    }


    private void setUserId(String userId) throws InvalidUserException {
        if (userId!=null&& userId.matches("[A-Z]{3}$")) {
            this.userId= userId;
        } else {
            throw new InvalidUserException("Invalid User ID");
        }
    }

    public void addOrder(OrderDTO order) {
        if (order != null) {
            orders.put(order.id, order);
        }
    }

    public boolean hasOrderWithRemainingQty(){
        for(OrderDTO order: orders.values()){
            if(order.remainingVolume>0){
                return true;
            }
        }
        return false;
    }

    public OrderDTO getOrderWithRemainingQty(){
        for(OrderDTO order: orders.values()){
            if(order.remainingVolume>0){
                return order;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        StringBuilder sb= new StringBuilder();
        sb.append("User Id: ").append(userId).append("\n");

        for (OrderDTO order : orders.values()) {
            sb.append("    ");
            sb.append("Product: ").append(order.product);
            sb.append(", Price: ").append(order.price);
            sb.append(", OriginalVolume: ").append(order.originalVolume);
            sb.append(", RemainingVolume: ").append(order.remainingVolume);
            sb.append(", CancelledVolume: ").append(order.cancelledVolume);
            sb.append(", FilledVolume: ").append(order.filledVolume);
            sb.append(", User: ").append(order.user);
            sb.append(", Side: ").append(order.side);
            sb.append(", Id: ").append(order.id);
            sb.append("\n");
        }
        return sb.toString();
    }

    @Override
    public void updateCurrentMarket(String symbol, CurrentMarketSide buySide, CurrentMarketSide sellSide) {
        CurrentMarketSide[] marketSides = new CurrentMarketSide[]{buySide,sellSide};
        currentMarkets.put(symbol,marketSides);
    }

    public String getCurrentMarkets(){
        StringBuilder sb = new StringBuilder();
        for(String symbol:currentMarkets.keySet()){
            CurrentMarketSide[] marketSides=currentMarkets.get(symbol);
            if(marketSides!=null&&marketSides.length==2){
                sb.append(symbol).append(" ").append(marketSides[0].toString()).append(" - ").append(marketSides[1].toString()).append("\n");
            }
        }
        return sb.toString();
    }
}
