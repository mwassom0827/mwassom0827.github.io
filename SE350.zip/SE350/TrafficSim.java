package SE350;


import java.util.HashMap;


public class TrafficSim {
    private static final HashMap<String,Double>basePrices = new HashMap<>();

    public static void runSim() throws InvalidInputException, InvalidPriceOperation, InvalidBasePriceException, InvalidUserException {

        UserManager.getInstance().init(new String[]{"ANN","BOB","CAT","DOG","EGG"});

        User annUser = UserManager.getUser("ANN");
        User bobUser = UserManager.getUser("BOB");
        User catUser = UserManager.getUser("CAT");
        User dogUser = UserManager.getUser("DOG");
        User eggUser = UserManager.getUser("EGG");

        CurrentMarketPublisher currentMarketPublisher =CurrentMarketPublisher.getInstance();

        currentMarketPublisher.subscribeCurrentMarket("WMT",annUser);
        currentMarketPublisher.subscribeCurrentMarket("TGT",annUser);
        currentMarketPublisher.subscribeCurrentMarket("TGT",bobUser);
        currentMarketPublisher.subscribeCurrentMarket("TSLA",bobUser);
        currentMarketPublisher.subscribeCurrentMarket("AMZN",catUser);
        currentMarketPublisher.subscribeCurrentMarket("TGT",catUser);
        currentMarketPublisher.subscribeCurrentMarket("WMT",catUser);
        currentMarketPublisher.subscribeCurrentMarket("TSLA",dogUser);
        currentMarketPublisher.subscribeCurrentMarket("WMT",eggUser);

        currentMarketPublisher.unsubscribeCurrentMarket("TGT",bobUser);

        ProductManager pm = ProductManager.getInstance();
        pm.addProduct("WMT");
        pm.addProduct("TGT");
        pm.addProduct("AMZN");
        pm.addProduct("TSLA");

        basePrices.put("WMT",140.98);
        basePrices.put("TGT",174.76);
        basePrices.put("AMZN",102.11);
        basePrices.put("TSLA",196.81);

        for(int i=0;i<10000;i++){

            User randomUser = UserManager.getInstance().getRandomUser();

            if(Math.random()<0.9){
                String randomProduct = ProductManager.getInstance().getRandomProduct();
                BookSide randomSide = (Math.random()<0.5)?BookSide.BUY:BookSide.SELL;
                int qty = (int)(25+(Math.random()*300));
                int orderVolume = (int) Math.round(qty/5.0)*5;
                Price randomPrice = getPrice(randomProduct,randomSide);
                Order order = new Order(randomUser.getUserId(),randomProduct,randomPrice,orderVolume,randomSide);
                OrderDTO orderDTO = pm.addOrder(order);

                randomUser.addOrder(orderDTO);

                System.out.println(orderDTO);

            }else{
                if(randomUser.hasOrderWithRemainingQty()){

                    OrderDTO randomOrderDTO = randomUser.getOrderWithRemainingQty();
                    OrderDTO cancelledOrder= pm.cancel(randomOrderDTO);
                    if(cancelledOrder!=null){
                        randomUser.addOrder((cancelledOrder));
                        System.out.println(i+") " +randomOrderDTO);

                    }

                }
            }
        }

        //System.out.println("\nCurrent Market Values:\n");
        System.out.println("\nANN: \n"+annUser.getCurrentMarkets());
        System.out.println("BOB: \n"+bobUser.getCurrentMarkets());
        System.out.println("CAT: \n"+catUser.getCurrentMarkets());
        System.out.println("DOG: \n"+dogUser.getCurrentMarkets());
        System.out.println("EGG: \n"+eggUser.getCurrentMarkets());

        currentMarketPublisher.unsubscribeCurrentMarket("ANN",annUser);
        currentMarketPublisher.unsubscribeCurrentMarket("BOB",bobUser);
        currentMarketPublisher.unsubscribeCurrentMarket("CAT",catUser);
        currentMarketPublisher.unsubscribeCurrentMarket("DOG",dogUser);
        currentMarketPublisher.unsubscribeCurrentMarket("EGG",eggUser);


        System.out.println("\n");
        //System.out.println(ProductManager.getInstance());
        //System.out.println(UserManager.getInstance());
    }
    public static Price getPrice(String symbol, BookSide side) throws InvalidBasePriceException {
        Double basePrice = basePrices.get(symbol);
        if(basePrice==null){
            throw new InvalidBasePriceException("Base price not found for symbol: "+symbol);
        }

        double priceWidth=0.02;
        double startPoint=0.01;
        double tickSize =0.1;

        double gapFromBase=basePrice*priceWidth;
        double priceVariance=gapFromBase*(Math.random());

        if(side==BookSide.BUY){
            double priceToUse = basePrice*(1-startPoint);
            priceToUse+=priceVariance;
            double priceToTick = Math.round(priceToUse*1/tickSize)/10.0;
            return PriceFactory.makePrice((int) (priceToTick*100));
        } else if(side==BookSide.SELL){
            double priceToUse = basePrice*(1-startPoint);
            priceToUse+=priceVariance;
            double priceToTick = Math.round(priceToUse*1/tickSize)/10.0;
            return PriceFactory.makePrice((int) (priceToTick*100));
        }
        return null;
    }
}
