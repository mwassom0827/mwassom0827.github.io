package SE350;

import static SE350.BookSide.BUY;
import static SE350.BookSide.SELL;

public class Main {

    public static void main(String[] args) throws InvalidPriceOperation, InvalidInputException, InvalidBasePriceException, InvalidUserException {
        TrafficSim.runSim();
    }
    }







